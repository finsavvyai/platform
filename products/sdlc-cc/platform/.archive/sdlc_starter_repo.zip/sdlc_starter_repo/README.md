# SDLC Starter Repo

This is a minimal, ready-to-extend skeleton aligned with the **SDLP v3** architecture.

## Structure
- `apps/gateway-go` — Go API gateway (AuthZ, OPA, metrics, audit)
- `apps/llm-gateway-go` — LLM provider abstraction & guards
- `apps/rag-py` — Python service for embeddings + retrieval orchestration
- `core/retrieval-rs` — Rust high-speed vector core (FFI surface)
- `packages/*` — policies (OPA), DLP configs, SDKs
- `platform/*` — docker-compose and Helm charts (skeletons)
- `ops/*` — runbooks & SLOs
- `docs/*` — API and architecture notes

See the world-scale playbook for specs.
