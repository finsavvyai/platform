# OpenSyber Skill: CI/CD Supply Chain Guardian
> New skill specification — written for Claude Code implementation
> Triggered by: Trivy supply chain attack, March 19 2026

---

## Overview

**Skill name:** `cicd-guardian`
**Display name:** CI/CD Supply Chain Guardian
**Category:** Security
**Version:** 1.0.0
**Audit tier:** 4-stage (same as existing security skills)

This skill audits GitHub Actions workflow files for unpinned action references,
detects mutable tag usage, scans for known-compromised action SHAs, and enforces
SHA pinning policy as a pre-push and scheduled check. It directly addresses the
root exploitation vector of the Trivy March 2026 supply chain attack.

---

## Background: Why This Skill Exists

The Trivy attack succeeded because:

1. `aquasecurity/trivy-action@v0.34.0` — a mutable tag — was silently
   re-pointed to a malicious commit containing a credential infostealer
2. Every downstream CI/CD pipeline that ran between 17:43–20:38 UTC on
   March 19 2026 executed attacker-controlled code with full runner privileges
3. The attack was invisible — workflows completed successfully with expected
   output while exfiltrating secrets in the background
4. 45 public repositories with 100+ stars were confirmed compromised

SHA pinning (`uses: action@sha256:abc...`) creates an immutable reference.
Even with full tag write access, an attacker cannot redirect a pinned digest.

---

## Skill Architecture

```
cicd-guardian/
├── manifest.json          # Skill manifest + permissions
├── scanner/
│   ├── workflow_parser.py # Parse .github/workflows/*.yml
│   ├── pin_checker.py     # Detect unpinned action references
│   ├── sha_resolver.py    # Resolve tags → current SHAs via GitHub API
│   ├── ioc_checker.py     # Check SHAs against known-compromised list
│   └── fixer.py           # Auto-pin: rewrite workflow files with SHAs
├── hooks/
│   └── pre_push.sh        # Git hook: block push if unpinned actions found
├── feed/
│   └── compromised_shas.json  # Live IOC feed (updated via OpenSyber threat intel)
└── report/
    └── formatter.py       # Generate finding reports for OpenSyber dashboard
```

---

## Implementation Spec

### 1. Workflow Parser (`workflow_parser.py`)

```python
"""
Scan all .github/workflows/*.yml files and extract action references.
Also covers .github/actions/ (composite actions) and reusable workflows.
"""

import glob
import yaml
from dataclasses import dataclass
from typing import Optional

@dataclass
class ActionRef:
    workflow_file: str
    job_name: str
    step_name: str
    action: str          # e.g. "aquasecurity/trivy-action"
    ref: str             # e.g. "v0.34.0" or "sha256:abc123..."
    line_number: int
    is_pinned: bool      # True only if ref is a full SHA256 digest
    is_first_party: bool # True if action is in same repo (./local-action)

def parse_workflows(repo_root: str) -> list[ActionRef]:
    refs = []
    patterns = [
        f"{repo_root}/.github/workflows/*.yml",
        f"{repo_root}/.github/workflows/*.yaml",
        f"{repo_root}/.github/actions/**/*.yml",
    ]
    for pattern in patterns:
        for path in glob.glob(pattern, recursive=True):
            refs.extend(_parse_file(path))
    return refs

def _parse_file(path: str) -> list[ActionRef]:
    # Parse YAML, walk jobs.*.steps[].uses
    # Detect: version tags (v1, v0.34.0), branch refs (main, master),
    #         SHA refs (40-char hex = git SHA, sha256: = OCI digest)
    # First-party refs (./) are excluded from pinning requirements
    pass

def is_pinned(ref: str) -> bool:
    """
    Only a full 40-char git SHA or sha256: OCI digest counts as pinned.
    Version tags (v1.2.3), branch names (main), and partial SHAs are NOT pinned.
    """
    import re
    git_sha = re.compile(r'^[0-9a-f]{40}$')
    oci_digest = re.compile(r'^sha256:[0-9a-f]{64}$')
    return bool(git_sha.match(ref) or oci_digest.match(ref))
```

---

### 2. SHA Resolver (`sha_resolver.py`)

```python
"""
For each unpinned action ref, resolve what SHA the tag currently points to.
This serves two purposes:
  a) Auto-pinning: replace the tag with its current SHA
  b) IOC checking: verify the SHA isn't in the compromised feed

Uses the GitHub API (no auth required for public repos, token for private).
"""

import httpx
from functools import lru_cache

GITHUB_API = "https://api.github.com"

@lru_cache(maxsize=512)
def resolve_tag_to_sha(owner: str, repo: str, tag: str, token: str = None) -> dict:
    """
    Returns:
      {
        "sha": "abc123...",           # full commit SHA
        "tagged_at": "2026-03-15T...",
        "tagger": "aqua-bot",
        "verified": True,             # whether commit is GPG signed
        "tag_type": "lightweight" | "annotated"
      }
    """
    headers = {"Accept": "application/vnd.github+json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    # Try annotated tag first (has its own SHA)
    url = f"{GITHUB_API}/repos/{owner}/{repo}/git/ref/tags/{tag}"
    resp = httpx.get(url, headers=headers)
    if resp.status_code == 200:
        data = resp.json()
        tag_sha = data["object"]["sha"]
        tag_type = data["object"]["type"]

        if tag_type == "tag":
            # Dereference annotated tag to get commit SHA
            tag_url = f"{GITHUB_API}/repos/{owner}/{repo}/git/tags/{tag_sha}"
            tag_resp = httpx.get(tag_url, headers=headers)
            commit_sha = tag_resp.json()["object"]["sha"]
        else:
            commit_sha = tag_sha

        return {
            "sha": commit_sha,
            "tag_type": "annotated" if tag_type == "tag" else "lightweight",
            "verified": _check_signature(owner, repo, commit_sha, headers),
        }

    return None

def _check_signature(owner, repo, sha, headers) -> bool:
    """Check if the commit has a verified GPG/SSH signature."""
    url = f"{GITHUB_API}/repos/{owner}/{repo}/commits/{sha}"
    resp = httpx.get(url, headers=headers)
    if resp.status_code == 200:
        verification = resp.json().get("commit", {}).get("verification", {})
        return verification.get("verified", False)
    return False
```

---

### 3. IOC Checker (`ioc_checker.py`)

```python
"""
Cross-reference resolved SHAs against the live OpenSyber threat intelligence
feed of known-compromised action commits.

Feed is updated every 15 minutes from:
  - GitHub Security Advisories API
  - Socket.dev threat feed
  - OpenSyber internal threat intel (aggregated from network of sensors)
  - StepSecurity compromise tracker
"""

import json
from datetime import datetime

# Trivy incident IOCs — seed data, feed will stay updated
KNOWN_COMPROMISED = {
    # aquasecurity/trivy-action compromised commits (March 19 2026)
    # Source: GHSA-69fq-xp46-6x23
    "aquasecurity/trivy-action": {
        "compromised_shas": [
            # These are the malicious commits that were force-pushed to tags
            # v0.0.1 through v0.34.2 were all re-pointed to one of these
            "PLACEHOLDER_SHA_1",  # Replace with actual IOC SHAs from advisory
            "PLACEHOLDER_SHA_2",
        ],
        "safe_from": "v0.35.0",
        "safe_sha": "PLACEHOLDER_SAFE_SHA",
        "incident": "GHSA-69fq-xp46-6x23",
        "incident_date": "2026-03-19",
        "exfil_domains": ["scan.aquasecurtiy.org"],  # note: typosquatted
        "c2_ips": ["45.148.10.212"],
        "persistence_indicators": ["sysmon.py", "pgmon"],
    },
    # aquasecurity/setup-trivy (all 7 tags compromised)
    "aquasecurity/setup-trivy": {
        "compromised_versions": ["v0.2.0", "v0.2.1", "v0.2.2", "v0.2.3", "v0.2.4", "v0.2.5", "v0.2.6"],
        "safe_from": "v0.2.6+",
        "incident": "GHSA-69fq-xp46-6x23",
    },
    # Checkmarx KICS action (follow-on compromise, same campaign)
    "Checkmarx/kics-github-action": {
        "compromised_versions": ["all tags"],
        "incident": "TeamPCP campaign March 2026",
    },
}

def check_action(action: str, sha: str, version: str) -> dict:
    """
    Returns:
      {
        "compromised": bool,
        "severity": "CRITICAL" | "HIGH" | "MEDIUM" | "INFO",
        "reason": str,
        "remediation": str,
        "incident_ref": str,
      }
    """
    entry = KNOWN_COMPROMISED.get(action)
    if not entry:
        return {"compromised": False}

    if sha in entry.get("compromised_shas", []):
        return {
            "compromised": True,
            "severity": "CRITICAL",
            "reason": f"SHA {sha[:12]}... is a confirmed malicious commit from {entry['incident']}",
            "remediation": f"Pin to safe SHA from {entry.get('safe_from', 'latest clean release')}",
            "incident_ref": entry.get("incident"),
        }

    if version in entry.get("compromised_versions", []):
        return {
            "compromised": True,
            "severity": "CRITICAL",
            "reason": f"Version {version} is confirmed compromised in {entry['incident']}",
            "remediation": "Rotate all secrets accessible to this pipeline immediately. Pin to safe version.",
            "incident_ref": entry.get("incident"),
        }

    return {"compromised": False, "severity": "INFO", "reason": "Not in IOC feed"}
```

---

### 4. Auto-Fixer (`fixer.py`)

```python
"""
Automatically rewrite workflow files to pin all action references to their
current SHA, with the original tag preserved as a comment for readability.

Input:  uses: aquasecurity/trivy-action@v0.34.2
Output: uses: aquasecurity/trivy-action@abc123def456...  # v0.34.2
"""

import re
import yaml

def pin_workflow_file(path: str, resolved_refs: dict, dry_run: bool = True) -> dict:
    """
    resolved_refs: { "owner/repo@tag": "full_sha" }
    dry_run: if True, returns diff without writing
    Returns: { "changes": int, "diff": str, "warnings": list }
    """
    with open(path) as f:
        content = f.read()

    original = content
    changes = 0
    warnings = []

    # Match: uses: owner/repo@ref (with optional whitespace)
    pattern = re.compile(
        r'(uses:\s*)([a-zA-Z0-9_.-]+/[a-zA-Z0-9_.-]+)@([^\s#\n]+)',
        re.MULTILINE
    )

    def replace_ref(match):
        nonlocal changes
        prefix, action, ref = match.group(1), match.group(2), match.group(3)

        if is_pinned(ref):
            return match.group(0)  # already pinned, leave alone

        key = f"{action}@{ref}"
        sha = resolved_refs.get(key)

        if not sha:
            warnings.append(f"Could not resolve {key} — skipping")
            return match.group(0)

        changes += 1
        return f"{prefix}{action}@{sha}  # {ref}"

    new_content = pattern.sub(replace_ref, content)

    if not dry_run and changes > 0:
        with open(path, 'w') as f:
            f.write(new_content)

    return {
        "changes": changes,
        "diff": _unified_diff(original, new_content, path),
        "warnings": warnings,
    }

def is_pinned(ref: str) -> bool:
    import re
    return bool(re.match(r'^[0-9a-f]{40}$', ref) or re.match(r'^sha256:[0-9a-f]{64}$', ref))
```

---

### 5. Pre-Push Hook (`hooks/pre_push.sh`)

```bash
#!/bin/bash
# OpenSyber CI/CD Guardian — pre-push hook
# Install: cp hooks/pre_push.sh .git/hooks/pre-push && chmod +x .git/hooks/pre-push
# Or via: opensyber skill install cicd-guardian --hook

set -e

OPENSYBER_API="${OPENSYBER_API_URL:-https://api.opensyber.cloud}"
AGENT_TOKEN="${OPENSYBER_AGENT_TOKEN}"

echo "🔍 OpenSyber: Scanning GitHub Actions for unpinned references..."

# Run the scanner
RESULT=$(python -m opensyber.skills.cicd_guardian.scanner \
  --repo-root "$(git rev-parse --show-toplevel)" \
  --format json \
  --strict)

UNPINNED=$(echo "$RESULT" | python -c "import json,sys; d=json.load(sys.stdin); print(d['unpinned_count'])")
COMPROMISED=$(echo "$RESULT" | python -c "import json,sys; d=json.load(sys.stdin); print(d['compromised_count'])")

if [ "$COMPROMISED" -gt 0 ]; then
  echo ""
  echo "🚨 BLOCKED: $COMPROMISED compromised action reference(s) detected"
  echo ""
  echo "$RESULT" | python -c "
import json, sys
d = json.load(sys.stdin)
for f in d['findings']:
    if f['compromised']:
        print(f'  ✗ {f[\"action\"]}@{f[\"ref\"]}')
        print(f'    → {f[\"reason\"]}')
        print(f'    → {f[\"remediation\"]}')
        print()
"
  echo "Run: opensyber cicd-guardian --fix to auto-pin all references"
  echo ""
  # Send alert to OpenSyber dashboard
  if [ -n "$AGENT_TOKEN" ]; then
    curl -s -X POST "$OPENSYBER_API/v1/events" \
      -H "Authorization: Bearer $AGENT_TOKEN" \
      -H "Content-Type: application/json" \
      -d "{\"type\":\"COMPROMISED_ACTION_BLOCKED\",\"severity\":\"CRITICAL\",\"data\":$RESULT}" \
      > /dev/null
  fi
  exit 1
fi

if [ "$UNPINNED" -gt 0 ]; then
  echo ""
  echo "⚠️  WARNING: $UNPINNED unpinned action reference(s) found"
  echo "   These are vulnerable to tag poisoning attacks (see: Trivy March 2026)"
  echo ""
  echo "   Run: opensyber cicd-guardian --fix  to auto-pin all references"
  echo ""
  # Warn but don't block (configurable: set OPENSYBER_STRICT=1 to block)
  if [ "${OPENSYBER_STRICT:-0}" = "1" ]; then
    exit 1
  fi
fi

echo "✅ OpenSyber: CI/CD Guardian check passed"
exit 0
```

---

### 6. Skill Manifest (`manifest.json`)

```json
{
  "name": "cicd-guardian",
  "display_name": "CI/CD Supply Chain Guardian",
  "version": "1.0.0",
  "category": "security",
  "description": "Audits GitHub Actions workflows for unpinned action references, detects tag poisoning via IOC feeds, and auto-pins to immutable SHA digests. Prevents Trivy-class supply chain attacks.",
  "author": "OpenSyber Security Team",
  "audit_stage": 4,
  "verified": true,
  "permissions": {
    "filesystem": ["read:.github/workflows/**", "write:.github/workflows/**"],
    "network": [
      "api.github.com",
      "threat-intel.opensyber.cloud",
      "socket.dev"
    ],
    "git_hooks": ["pre-push", "pre-commit"]
  },
  "configuration": {
    "strict_mode": {
      "type": "boolean",
      "default": false,
      "description": "Block push on unpinned references (not just compromised ones)"
    },
    "auto_fix": {
      "type": "boolean",
      "default": false,
      "description": "Automatically rewrite workflow files to pin all references"
    },
    "github_token": {
      "type": "secret",
      "required": false,
      "description": "GitHub PAT for resolving private action SHAs. Read-only scope sufficient."
    },
    "exclude_actions": {
      "type": "array",
      "default": [],
      "description": "Action refs to exclude from pinning requirements (e.g. internal actions)"
    },
    "scheduled_scan": {
      "type": "cron",
      "default": "0 */6 * * *",
      "description": "How often to re-scan for newly compromised references in the IOC feed"
    }
  },
  "dashboard_widgets": [
    "unpinned_count",
    "pinned_percentage",
    "ioc_matches",
    "last_scan_time",
    "actions_by_risk"
  ],
  "alert_channels": ["opensyber_dashboard", "slack", "pagerduty", "email"],
  "remediation_actions": [
    {
      "id": "auto_pin_all",
      "label": "Auto-pin all references",
      "description": "Rewrite all workflow files to use SHA digests. Creates a PR for review.",
      "requires_approval": true
    },
    {
      "id": "generate_pr",
      "label": "Generate fix PR",
      "description": "Open a GitHub PR with all SHA-pinned workflow changes",
      "requires_approval": true
    }
  ]
}
```

---

### 7. Scheduled IOC Feed Update

```python
# runs on OpenSyber's scheduled scan (every 15 minutes, same as threat feed)

async def refresh_ioc_feed():
    """
    Pull latest compromised action SHAs from:
    1. GitHub Security Advisories (GraphQL API)
    2. StepSecurity compromise tracker API
    3. Socket.dev malicious packages API
    4. OpenSyber internal threat intel aggregator
    """
    sources = [
        fetch_github_advisories(ecosystem="actions"),
        fetch_stepsecurity_feed(),
        fetch_socket_dev_feed(type="github-action"),
        fetch_opensyber_internal(),
    ]
    results = await asyncio.gather(*sources, return_exceptions=True)

    merged = merge_ioc_feeds(results)
    await store_ioc_feed(merged)
    await notify_agents_with_active_matches(merged)
```

---

## OpenSyber Dashboard Integration

### New event types to add:

```typescript
// Add to event schema
type CICDGuardianEvent =
  | { type: 'UNPINNED_ACTION_DETECTED'; action: string; ref: string; workflow: string; risk: 'HIGH' | 'MEDIUM' }
  | { type: 'COMPROMISED_ACTION_BLOCKED'; action: string; ref: string; incident: string; severity: 'CRITICAL' }
  | { type: 'AUTO_PIN_APPLIED'; workflow: string; changes: number; pr_url?: string }
  | { type: 'IOC_FEED_MATCH'; action: string; sha: string; campaign: string }
  | { type: 'CICD_SCAN_COMPLETE'; total: number; unpinned: number; compromised: number; pinned_pct: number }
```

### New security score dimension to add:

```typescript
// Add to the 8-point security scoring system (currently: Gateway, Credential,
// Docker, Skill, Firewall, Auto-Patching, Audit, Network)
// Propose adding as dimension 9:

{
  id: 'cicd_posture',
  label: 'CI/CD Posture',
  description: 'GitHub Actions SHA pinning coverage and IOC cleanliness',
  weight: 10,  // out of 100 total
  scoring: (data) => {
    const pinnedPct = data.pinned_actions / data.total_actions
    const hasCompromised = data.compromised_count > 0
    if (hasCompromised) return 0  // critical: compromised action = 0 score
    if (pinnedPct === 1.0) return 100
    if (pinnedPct >= 0.9) return 80
    if (pinnedPct >= 0.7) return 55
    if (pinnedPct >= 0.5) return 30
    return 10
  }
}
```

---

## Demo Page Update

Update the mock events in `opensyber.cloud/demo` to include CI/CD Guardian events:

```javascript
// Add to mockEvents array in the demo page
{
  severity: "CRITICAL",
  message: "Compromised GitHub Action blocked — aquasecurity/trivy-action@v0.34.0",
  detail: "SHA matches known IOC from GHSA-69fq-xp46-6x23. Push blocked.",
  time: "3m ago",
  resolved: true,
  skill: "cicd-guardian"
},
{
  severity: "WARN",
  message: "23 unpinned GitHub Actions references detected",
  detail: "Run 'opensyber cicd-guardian --fix' to auto-pin",
  time: "1h ago",
  resolved: false,
  skill: "cicd-guardian"
}
```

---

## Acceptance Criteria (for Claude Code)

- [ ] `cicd-guardian` skill appears in marketplace with Verified badge
- [ ] Scanner correctly identifies pinned vs unpinned refs in a test workflow
- [ ] SHA resolver calls GitHub API and caches results
- [ ] IOC feed seeded with Trivy incident data and refreshes every 15min
- [ ] Auto-fixer rewrites workflow files with correct SHA + comment
- [ ] Pre-push hook installs and blocks on compromised refs
- [ ] New dashboard events surface in Recent Security Events
- [ ] CI/CD Posture score dimension appears in security score breakdown
- [ ] `strict_mode: true` blocks push on any unpinned ref
- [ ] PR generation creates a real GitHub PR via API

---

*Priority: ship within 1 week of the Trivy incident (March 19 2026) while the news is live*
