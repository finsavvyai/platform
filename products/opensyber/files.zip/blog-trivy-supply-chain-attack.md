# The Trivy Attack Was Inevitable. Here's What It Means for AI Agent Security.

**Published:** March 28, 2026  
**Author:** OpenSyber Security Research  
**Tags:** Supply Chain, CI/CD, GitHub Actions, AI Agent Security, TokenForge

---

On March 19, 2026 at 17:43 UTC, a security scanner became a weapon.

Trivy — the most widely deployed open-source vulnerability scanner in the world, trusted by hundreds of thousands of CI/CD pipelines to *find* malware — was silently turned into malware. For approximately 12 hours, every pipeline that ran a Trivy vulnerability scan became an attack surface. Credentials were stolen. Secrets were exfiltrated. A worm spread through npm. And a persistent backdoor was planted on developer machines masquerading as a PostgreSQL monitoring service.

The irony was deliberate. The attackers, identified as TeamPCP, chose Trivy specifically *because* security teams trust it. They wanted to exploit the gap between trust and verification.

It worked.

---

## What Actually Happened

The attack was a two-stage supply chain compromise. Understanding both stages is important because they exploited fundamentally different weaknesses.

**Stage one (late February 2026):** An autonomous bot called hackerbot-claw exploited a `pull_request_target` workflow misconfiguration in the Trivy repository. This is a well-documented GitHub Actions vulnerability — when a workflow triggers on pull requests with elevated permissions, a malicious PR from a fork can execute code with access to the parent repository's secrets. The bot stole a Personal Access Token with write access to the repository.

**Stage two (March 19 2026):** After incomplete credential rotation — the Trivy team rotated secrets on March 1 but not atomically, allowing the attacker to capture refreshed tokens during the rotation window — TeamPCP used the retained access to execute a sophisticated multi-vector attack:

- Force-pushed 76 of 77 version tags in `aquasecurity/trivy-action` to commits containing a Python infostealer
- Force-pushed all 7 tags in `aquasecurity/setup-trivy` to malicious commits
- Published malicious binary v0.69.4 to GitHub Releases, Docker Hub, GHCR, and ECR
- Configured the infostealer to run silently alongside legitimate Trivy scans — workflows completed with expected output

The infostealer extracted SSH keys, cloud provider credentials, Git configuration, Docker auth, Kubernetes tokens, and any other secrets accessible to the CI/CD runner, exfiltrating them to a typosquatted domain (`scan.aquasecurtiy[.]org` — note the transposed 'i' and 'y') and a fallback C2 hosted on an ICP blockchain canister.

After exfiltration, it planted a persistent systemd service (`sysmon.py`) masquerading as PostgreSQL tooling on developer machines. The campaign then expanded — using stolen npm publish tokens, a worm called CanisterWorm propagated through the npm ecosystem. A parallel compromise of the Checkmarx KICS GitHub Action used the same infrastructure.

45 public repositories with 100+ stars are confirmed to have run compromised code during the incident window.

---

## The Root Cause Is Not What You Think

The narrative around this attack focuses on the mutable Git tag problem. That's real and important — anyone with tag write access can silently redirect `v0.34.0` to malicious code without creating a new release, and most CI/CD pipelines would never notice. SHA pinning (`uses: aquasecurity/trivy-action@abc123def456...`) creates an immutable reference that no tag manipulation can subvert.

But mutable tags are a symptom. The root cause is simpler: **stolen credentials with too much access, held for too long, without device binding.**

The entire attack chain collapses if:
1. The stolen PAT cannot be used from attacker infrastructure (device binding)
2. Tag write access is scoped more narrowly (least privilege)
3. Credential rotation is atomic and comprehensive (operational hygiene)

Two of those three are technical problems. One is human.

---

## Where TokenForge Fits

TokenForge is OpenSyber's session security layer. It creates cryptographic device binding for every session — ECDSA P-256 keypairs generated in the browser's Web Crypto API as non-extractable keys, with challenge-response signing on every request.

In the Trivy context: the stolen PAT was a long-lived token with no binding to the device or context that created it. The moment it was extracted from the CI/CD runner's memory, it was fully portable. TeamPCP could use it from anywhere in the world without detection.

A TokenForge-protected credential changes this fundamentally. The credential alone is insufficient — every request must also be signed by the device's private key, which is non-extractable from the Web Crypto API. When the attacker attempts to use the stolen token from their infrastructure:

- **`ip_match: fail`** — different IP range from the CI/CD runner
- **`geo_match: fail`** — different geographic region
- **`fingerprint: fail`** — different device fingerprint
- **`signature: missing`** — no device private key, no valid signature

The trust score engine drops below threshold. Step-up authentication is triggered, or the request is blocked outright. The credential is worthless without the device it was bound to.

This is not a panacea. TokenForge is designed for user sessions and API credentials, not every possible CI/CD secret type. But the pattern — device-bound tokens that fail when used from attacker infrastructure — is the right architectural direction for any credential that matters.

---

## Where OpenSyber Fits

OpenSyber operates at the runtime layer — monitoring what your AI agents and development tools actually *do*, rather than just scanning for vulnerabilities before they run. The Trivy attack succeeds specifically because the malicious payload executes at runtime, invisibly alongside legitimate scan output.

Three OpenSyber skills are directly relevant:

**Supply Chain Guard** monitors npm, PyPI, and Go module installations for supply chain attack indicators — typosquatting, suspicious postinstall scripts, and unexpected network calls — using the Socket.dev threat feed and OpenSyber threat intelligence. The CanisterWorm npm packages would have been flagged before installation.

**Network Sentinel** performs real-time network traffic analysis. The exfiltration call to `scan.aquasecurtiy[.]org` — a freshly registered, typosquatted domain — is exactly the pattern Network Sentinel detects: suspicious outbound connections to domains with low reputation and recent registration dates. The periodic beaconing to the ICP canister C2 is another detectable pattern.

**Git Guardian** enforces pre-commit and pre-push hook policies including blocking force-pushes to protected branches. This wouldn't have stopped tag poisoning directly (tags aren't branches), but a more complete CI/CD policy enforcement would.

That brings us to the skill we're shipping this week.

---

## Introducing: CI/CD Supply Chain Guardian

The Trivy attack exposed a gap in OpenSyber's coverage: we monitored runtime behavior but didn't audit the CI/CD configuration that *defines* what runs. Starting today, that changes.

**CI/CD Supply Chain Guardian** is a new verified skill that:

**Audits GitHub Actions workflows for unpinned references.** Every `uses:` directive that references a mutable tag rather than a full SHA digest is a potential attack surface. The skill scans all `.github/workflows/*.yml` files and generates a pinning coverage report with per-file findings.

**Resolves current SHAs for all detected references.** For each unpinned action, the skill calls the GitHub API to resolve what commit the tag currently points to, caches results, and verifies whether commits are GPG signed.

**Cross-references against a live IOC feed.** The compromised Trivy action SHAs from the March 2026 incident are in the feed today. As new supply chain compromises emerge, the feed updates every 15 minutes from GitHub Security Advisories, StepSecurity's compromise tracker, and Socket.dev's threat intelligence. Any workflow running a known-compromised SHA triggers a CRITICAL alert immediately.

**Auto-pins with one command.** Running `opensyber cicd-guardian --fix` rewrites all workflow files to replace mutable tags with full SHA digests. The original tag is preserved as a comment for readability. A PR is generated for review before any changes land.

**Blocks compromised actions at the pre-push hook.** Installed as a Git pre-push hook, the skill prevents any push to a repository with a workflow referencing a confirmed-compromised action SHA. You cannot accidentally ship malicious CI/CD configuration.

**Contributes to your security score.** CI/CD Posture becomes the ninth dimension of OpenSyber's 87-point security scoring system. 100% SHA pinning with a clean IOC check yields full score. A single confirmed-compromised action reference drops it to zero.

The fix for the specific Trivy attack is three words: **pin your actions.** Change every `uses: aquasecurity/trivy-action@v0.34.2` to `uses: aquasecurity/trivy-action@abc123...` and tag poisoning becomes physically impossible regardless of who controls the repository.

---

## Where TenantIQ Fits

For MSPs running Microsoft 365 environments, the Trivy attack creates a specific downstream risk: CI/CD pipelines that contained M365 service account credentials, Graph API app registration secrets, or Azure AD tokens may have had those credentials extracted by the infostealer.

TenantIQ operates at the M365 layer, and its threat detection is directly relevant here.

The CI/CD Credential Abuse detection rule — shipping as part of TenantIQ's supply chain response update this week — identifies when a service principal that previously only appeared from known CI/CD runner IP ranges (GitHub Actions, Azure DevOps, GitLab CI) suddenly appears from an unrecognized IP. This is the exact pattern of stolen credential use: the attacker has the token but not the runner context it came from.

When this fires, TenantIQ surfaces:
- All actions taken by the credential since the suspected compromise date
- All conditional access policy changes in the incident window
- A Blast Radius Report showing what an attacker with these permissions can access
- Recommended immediate actions: revoke, rotate, audit

The Trivy incident window (March 19 17:43 UTC through March 23 01:36 UTC) is now tagged in TenantIQ's drift detection engine. Any configuration changes made to your M365 tenants during this window are surfaced with elevated severity and flagged as potentially attacker-originated.

The App Registration Secret Audit — also shipping this week — identifies service principals with secrets older than 90 days, and specifically flags any secret created or last rotated during the Trivy incident window. If a secret was rotated on March 20 because someone followed remediation guidance, and that rotation happened while TeamPCP still had access, the new secret may have been captured during the rotation. TenantIQ will tell you.

---

## The Pattern to Internalize

The Trivy attack is not an anomaly. It is a preview.

Supply chain attacks are increasing in sophistication and frequency because they are efficient. A single compromise of a widely-used tool provides access to thousands of downstream environments simultaneously, with credentials that arrive already trusted, from IP ranges that are expected, running processes that complete successfully. The attacker's code ran inside legitimate vulnerability scans and nobody noticed for 12 hours.

The security community has known about mutable Git tags for years. The `pull_request_target` misconfiguration is documented. Long-lived tokens with excessive scope are a known anti-pattern. None of this is new knowledge. The reason the attack succeeded is that knowing and operationalizing are different things.

The operational response is:

1. **Pin your GitHub Actions to SHA digests.** Not version tags. Full 40-character commit SHAs. Today.
2. **Treat every CI/CD secret as potentially compromised** if any pipeline ran `aquasecurity/trivy-action` or `aquasecurity/setup-trivy` between March 19 17:43 UTC and March 23 01:36 UTC.
3. **Check for `tpcp-docs` repositories in your GitHub organization.** Their presence indicates the fallback exfiltration mechanism fired and secrets were successfully stolen.
4. **Block `scan.aquasecurtiy[.]org` and `45.148.10.212`** at the network level.
5. **Check developer machines for `sysmon.py` or `pgmon` systemd services.**
6. **Rotate any M365 credentials that were accessible to affected pipelines** — and do it atomically, not sequentially.

The last point is worth emphasizing. Incomplete, non-atomic credential rotation is what turned the February incident into the March catastrophe. Rotate everything at once, or rotate nothing — partial rotation hands the attacker freshly issued credentials during the window between rotations.

---

## What's Next

The skills and features described in this post are shipping to OpenSyber and TenantIQ this week.

For OpenSyber users: **CI/CD Supply Chain Guardian** will appear in your marketplace as a Verified skill. Install it, run the initial scan, and use `--fix` to pin everything. The pre-push hook installation takes 30 seconds.

For TenantIQ users: The **Incident Response** flow and **CI/CD Credential Abuse** detection are live in your dashboard. If your organization may have been affected by the Trivy incident, run the Supply Chain Breach assessment from the Security → Incident Response tab. It will tell you in under five minutes what an attacker with your CI/CD credentials could have accessed.

For everyone: verify you are running `trivy-action@v0.35.0` or later, pinned to its SHA. The sole clean tag from the incident was `v0.35.0` — every other tag from `v0.0.1` to `v0.34.2` was poisoned.

The attack on Trivy was sophisticated. The defense is not. Pin your actions.

---

*OpenSyber is a runtime security platform for AI agents. TenantIQ is an AI-powered Microsoft 365 operations platform for MSPs. TokenForge is OpenSyber's device-bound session security layer. All three are in early access — [start free at opensyber.cloud](https://opensyber.cloud/sign-up).*

---

**References**

- GitHub Security Advisory: GHSA-69fq-xp46-6x23
- Aqua Security incident blog: aquasec.com/blog/trivy-supply-chain-attack-what-you-need-to-know
- StepSecurity analysis: stepsecurity.io/blog/trivy-compromised-a-second-time
- Wiz Research: wiz.io/blog/trivy-compromised-teampcp-supply-chain-attack
- Docker Hub advisory: docker.com/blog/trivy-supply-chain-compromise-what-docker-hub-users-should-know
- Microsoft Security Blog: microsoft.com/security/blog/2026/03/24/detecting-investigating-defending-against-trivy-supply-chain-compromise
- GitHub Actions security hardening: docs.github.com/en/actions/reference/security/secure-use
