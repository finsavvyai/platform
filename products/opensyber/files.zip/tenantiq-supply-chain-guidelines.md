# TenantIQ — Supply Chain Attack Response Guidelines
> Internal spec: how TenantIQ detects and limits blast radius of CI/CD supply chain attacks
> Triggered by: Trivy March 2026 incident

---

## The Problem TenantIQ Solves (Post-Breach)

TenantIQ doesn't prevent CI/CD supply chain attacks — that's OpenSyber's job.
TenantIQ's role is **blast radius limitation**: after credentials are stolen from
a compromised CI/CD pipeline, TenantIQ detects their use in M365 environments
before an attacker can pivot into client tenants.

The Trivy infostealer specifically targeted:
- SSH keys
- Cloud provider credentials (AWS, GCP, Azure)
- Git credentials
- Docker configurations
- Kubernetes tokens
- **Any secrets accessible to the CI/CD runner**

For MSPs, that last point is the dangerous one. If an MSP's pipeline contained
M365 service account credentials, app registration secrets, or Graph API tokens,
those are now in the hands of TeamPCP.

---

## New Feature: Supply Chain Breach Response Mode

### What to build

Add a dedicated "Supply Chain Incident" response flow to TenantIQ that MSPs can
activate when they discover their CI/CD pipeline may have been compromised.

```
Dashboard → Security → Incident Response → Supply Chain Breach
```

This flow should:
1. Immediately audit all service principal and app registration activity
2. Flag any M365 sign-ins from unfamiliar IPs/devices in the last 72 hours
3. Surface any conditional access policy changes
4. Generate a "Blast Radius Report" showing what an attacker with stolen credentials could access

---

## Implementation Spec

### 1. New Detection Rule: CI/CD Credential Abuse

Add to the existing threat detection engine:

```typescript
// New rule: detect service principal used from CI/CD IP ranges
// then suddenly used from an unknown IP (credential theft pattern)

interface CICDCredentialAbuseRule {
  id: 'cicd_credential_abuse';
  name: 'CI/CD Credential Abuse Detected';
  severity: 'CRITICAL';

  detection: {
    // Step 1: build baseline of known CI/CD runner IP ranges
    // (GitHub Actions, GitLab CI, Azure DevOps, Bitbucket Pipelines)
    knownCICDRanges: string[];  // fetch from Meta API of each provider

    // Step 2: flag when a service principal that previously only appeared
    // from CI/CD ranges suddenly appears from a non-CI/CD IP
    trigger: (signInLogs: SignInLog[]) => {
      // Group by service principal / app registration
      // If last N sign-ins were from CI/CD ranges but latest is NOT → alert
    };
  };

  response: {
    alertChannels: ['dashboard', 'sms', 'email'];
    suggestedActions: [
      'Revoke service principal credentials immediately',
      'Rotate all Graph API app registration secrets',
      'Audit conditional access policy changes in last 72h',
      'Review all tenant changes made by this service principal',
    ];
  };
}
```

**GitHub Actions IP ranges** (fetch dynamically from GitHub's Meta API):
```typescript
async function getGitHubActionsIPRanges(): Promise<string[]> {
  const resp = await fetch('https://api.github.com/meta');
  const data = await resp.json();
  return data.actions; // returns current IP CIDR ranges
}
// Schedule refresh: daily — GitHub rotates these ranges
// Cache in Cloudflare KV with 24h TTL
```

---

### 2. New Audit: App Registration Secret Rotation Check

Surface which app registrations have secrets that haven't been rotated recently
and flag any that were used during the Trivy incident window.

```typescript
// New scheduled job — runs daily at 4 AM UTC

async function auditAppRegistrationSecrets(tenantId: string) {
  // Fetch all app registrations via Graph API
  const apps = await graphClient
    .api('/applications')
    .select(['id', 'displayName', 'passwordCredentials', 'keyCredentials'])
    .get();

  const findings = [];

  for (const app of apps.value) {
    for (const secret of app.passwordCredentials) {
      const ageInDays = daysSince(secret.startDateTime);
      const expiresInDays = daysUntil(secret.endDateTime);

      if (ageInDays > 90) {
        findings.push({
          app: app.displayName,
          secretId: secret.keyId,
          ageInDays,
          severity: ageInDays > 365 ? 'HIGH' : 'MEDIUM',
          reason: `Secret is ${ageInDays} days old — likely predates any recent rotation`,
          recommendation: 'Rotate immediately if this app was used in CI/CD pipelines',
        });
      }

      // Flag secrets that were created/modified during Trivy incident window
      const trivyIncidentStart = new Date('2026-03-19T17:43:00Z');
      const trivyIncidentEnd = new Date('2026-03-23T01:36:00Z');
      const lastModified = new Date(secret.startDateTime);

      if (lastModified >= trivyIncidentStart && lastModified <= trivyIncidentEnd) {
        findings.push({
          app: app.displayName,
          secretId: secret.keyId,
          severity: 'CRITICAL',
          reason: 'Secret was created/rotated during the Trivy supply chain incident window',
          recommendation: 'This secret may have been captured during rotation. Rotate again immediately.',
        });
      }
    }
  }

  return findings;
}
```

---

### 3. Blast Radius Report

New report type in the AI Agent's tool suite (add as tool #14):

```typescript
{
  name: 'generate_blast_radius_report',
  description: 'Generate a report showing what an attacker with stolen M365 credentials could access',
  parameters: {
    tenantId: string;
    credentialType: 'service_principal' | 'user_account' | 'app_registration';
    credentialId: string;
    assumedCompromiseDate: string; // ISO date
  },
  execute: async (params) => {
    // Fetch all permissions granted to this credential
    const permissions = await getGrantedPermissions(params.credentialId);

    // Fetch all audit log actions taken by this credential since compromise date
    const actions = await getAuditLogsByActor(params.credentialId, params.assumedCompromiseDate);

    // Cross-reference permissions with sensitive data locations
    const riskAreas = assessRisk(permissions);

    return {
      credential: params.credentialId,
      permissions_granted: permissions,
      actions_since_compromise: actions,
      sensitive_data_at_risk: riskAreas,
      recommended_immediate_actions: generateRemediationPlan(permissions, riskAreas),
      estimated_severity: scoreSeverity(permissions, actions),
    };
  }
}
```

---

### 4. New Compliance Check: CI/CD Secret Hygiene

Add to the CIS Benchmark scanning engine (extends existing 100+ controls):

```typescript
// New CIS-adjacent controls for CI/CD credential hygiene

const cicdSecretControls = [
  {
    id: 'CICD-01',
    name: 'Service principal secrets rotation',
    description: 'All service principals used in CI/CD have secrets rotated within 90 days',
    severity: 'HIGH',
    check: async (tenant) => checkSecretAge(tenant, 90),
  },
  {
    id: 'CICD-02',
    name: 'CI/CD app registrations use certificate auth',
    description: 'App registrations used in CI/CD use certificates rather than client secrets where possible',
    severity: 'MEDIUM',
    check: async (tenant) => checkCertificateAuth(tenant),
  },
  {
    id: 'CICD-03',
    name: 'Conditional access covers service principals',
    description: 'Conditional access policies include workload identity conditions for service principals',
    severity: 'HIGH',
    check: async (tenant) => checkWorkloadIdentityCA(tenant),
  },
  {
    id: 'CICD-04',
    name: 'Named locations exclude CI/CD runner ranges',
    description: 'CI/CD runner IP ranges are defined as named locations and excluded from trusted locations',
    severity: 'MEDIUM',
    check: async (tenant) => checkCICDNamedLocations(tenant),
  },
];
```

---

### 5. AI Agent: New Suggested Prompts

Add to the AI agent's suggested action buttons after any threat detection event:

```typescript
// When severity >= HIGH event is detected:
const suggestedPrompts = [
  "Check if any service principals were used from unusual IPs in the last 72 hours",
  "Show me all conditional access policy changes made in the last 7 days",
  "Which app registrations have secrets older than 90 days?",
  "Generate a blast radius report for any compromised credentials",
  "Compare current conditional access policies to last week's snapshot",
];
```

---

### 6. Drift Detection: Flag Post-Incident Policy Changes

Update the Config Snapshot + Drift Detection to flag changes during known
incident windows with elevated severity:

```typescript
// In drift_detector.ts — add incident window awareness

const KNOWN_INCIDENT_WINDOWS = [
  {
    name: 'Trivy Supply Chain Attack',
    start: '2026-03-19T17:43:00Z',
    end: '2026-03-23T01:36:00Z',
    severity_multiplier: 2,  // double the severity of any drift in this window
    reason: 'Changes during this window may indicate attacker activity using stolen credentials',
    advisory: 'GHSA-69fq-xp46-6x23',
  },
  // Add future incidents here
];

function assessDriftSeverity(change: ConfigChange): DriftSeverity {
  let baseSeverity = calculateBaseSeverity(change);

  for (const window of KNOWN_INCIDENT_WINDOWS) {
    if (isWithinWindow(change.timestamp, window)) {
      return escalateSeverity(baseSeverity, window.severity_multiplier, window.reason);
    }
  }

  return baseSeverity;
}
```

---

## Dashboard UI Changes

### New "Incident Response" tab in Security section

```
Security
├── CIS Benchmark
├── Threat Detection
├── Risky Users
├── Sign-In Logs
└── Incident Response  ← NEW
    ├── Active Incidents
    ├── Supply Chain Breach  ← NEW FLOW
    ├── Blast Radius Reports
    └── Credential Audit
```

### New banner when supply chain incident is active

```svelte
<!-- Show when a known incident window overlaps with the last 30 days -->
{#if activeIncidents.length > 0}
  <div class="incident-banner critical">
    <span class="icon">⚠️</span>
    <div>
      <strong>Active supply chain incident: {activeIncidents[0].name}</strong>
      <p>
        Check if your CI/CD pipelines were exposed between
        {formatDate(activeIncidents[0].start)} and {formatDate(activeIncidents[0].end)}.
        <a href="/security/incident-response">Run blast radius assessment →</a>
      </p>
    </div>
  </div>
{/if}
```

---

## Acceptance Criteria

- [ ] CI/CD credential abuse rule fires when service principal appears from non-CI/CD IP
- [ ] GitHub Actions IP ranges refreshed daily from Meta API
- [ ] App registration secret age audit runs daily and surfaces findings in dashboard
- [ ] Trivy incident window flagged in drift detection with elevated severity
- [ ] Blast radius report tool added to AI agent (tool #14)
- [ ] 4 new CIS-adjacent CICD controls appear in benchmark scanning
- [ ] Incident Response tab added to Security section
- [ ] Supply chain breach response flow completable in < 5 minutes by an MSP tech
- [ ] Incident banner shown when known incident window overlaps last 30 days

---

*Estimated effort: 3–5 days. Prioritize items 1, 2, and 6 — they deliver immediate value
with the Trivy incident still live in the news cycle.*
